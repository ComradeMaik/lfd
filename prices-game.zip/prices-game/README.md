# Prices Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/ComradeMaik/pen/MWqQxgN](https://codepen.io/ComradeMaik/pen/MWqQxgN).

