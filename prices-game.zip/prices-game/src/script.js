// Define the product prices
document.addEventListener("DOMContentLoaded", function() {
  // Your JavaScript code goes here
});
const answers = {
  "zombie": 12,
  "negroni": 9,
  "basil-smash": 9,
  "dudu-shot": 4
};

function checkAnswers() {
  let correctAnswers = 0;
  let totalAnswers = 0;

  for (const [name, price] of Object.entries(answers)) {
    const input = document.getElementById(name);
    if (input.value !== "") {
      const userPrice = parseFloat(input.value);
      if (userPrice === price) {
        correctAnswers++;
      }
      totalAnswers++;
    }
  }

  const percentage = Math.round((correctAnswers / totalAnswers) * 100);

  const resultDiv = document.getElementById("result");
  resultDiv.innerHTML = `You got ${percentage}% correct!`;

  // show the result
  resultDiv.style.display = "block";
}